 module app.common {
    angular.module("common.services",
         ["ngResource"]);
 }