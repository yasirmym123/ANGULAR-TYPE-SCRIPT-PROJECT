  module  app {
    angular.module("productManagement",
                     []);
  }
