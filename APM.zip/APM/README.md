# Angular-TypeScript
Starter files and support materials for the Pluralsight course: "Angular with TypeScript"

